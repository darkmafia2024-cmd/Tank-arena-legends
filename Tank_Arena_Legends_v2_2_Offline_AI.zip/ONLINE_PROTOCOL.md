# Online room relay protocol (v2.1)

- `create`: create a room; creator is assigned slot 0.
- `join`: join a room by its 5-character code; joiner is assigned slot 1.
- `ready`: mark the connected player ready.
- `match-ready`: broadcast when both connected players are ready.
- `relay`: forward a JSON object (maximum 4 KB) to the other player as `peer-message`, including sender slot in `from`.
- `peer-left` / `room-closed`: disconnect lifecycle notices.

Security note: this is an untrusted peer relay, not an authoritative game server. Do not use it for ranked play, purchases, or security-sensitive state. Combat synchronization must be implemented and validated separately.
