# TANK ARENA: LEGENDS — v2.2 Android Build Package

This is an updated, APK-build-ready source package based on the supplied v2.0 ZIP, with a new offline rival AI update.

## Included gameplay
- 60 unlocked tank profiles and unlimited displayed coins
- 120 selectable campaign mission configurations
- Turn-based artillery-style arcade duel against computer AI
- Real-time arcade rumble with touch movement, hop and energy shots
- Offline AI rival in both battle modes: a random tank is selected for every match, with independent rival stats
- Real-time rival AI moves to maintain distance, dodges incoming shots, aims and fires automatically
- Turn-based AI chooses its own firing angle and power
- Battle result offers NEXT MATCH · NEW RIVAL to start another match immediately
- Garage, tank stats, mission progress and local save
- Responsive mobile UI, procedural arena visuals, projectile effects and HP bars
- PWA manifest and service worker

## Offline AI update
Each match randomly selects one of the other 59 tanks as the computer rival. The rival tank name and stats are independent of the player selection. In real-time mode, the rival automatically moves, reacts to incoming shots, and fires toward the player. In turn-based mode, it chooses its own shot angle and power. Selecting Next Match starts a fresh battle with a newly selected rival.

## Online status — important
The included Node.js WebSocket server supports room creation, joining, ready-state matchmaking, disconnect notices, and small peer-message relay. It is a lobby/relay foundation only. It does **not** provide complete synchronized PvP combat, authoritative hit validation, reconnect recovery, accounts, anti-cheat, or public matchmaking. The game UI currently reports peer events; do not treat this as finished online combat.

## Build Android APK with GitHub Actions
This package includes `.github/workflows/build-android.yml`.

1. Extract this ZIP.
2. Upload **the contents** (not the ZIP file itself) to a new GitHub repository.
3. Open the repository's **Actions** tab.
4. Select **Build Tank Arena Android APK**.
5. Tap **Run workflow** and wait for the workflow to finish.
6. Open the successful run and download the `Tank-Arena-Legends-APK` artifact.
7. Extract the artifact ZIP; it contains `app-debug.apk`.

The workflow creates a Capacitor Android project, syncs the web game, and builds a debug APK. The APK is unsigned for Play Store release; Android may show the normal install warning for an APK installed outside the Play Store.

## Local browser test
Serve this folder with a local web server or host it over HTTPS. Opening `index.html` directly may restrict some browser features.

## Online server
Deploy the `server/` folder to a Node.js host that supports WebSockets. It uses `PORT` from the host environment and exposes a simple HTTP status endpoint. Enter its public `wss://` URL in the game's Online Arena page.

## Honest limitations / remaining work
- True synchronized online battle still needs client-side battle-state integration and server-side validation.
- Campaign missions share the same core battle loop with scaled enemy durability and arena themes; they are not 120 individually scripted levels.
- The tank profiles use procedural artwork rather than 60 bespoke high-resolution tank sprites.
- This package has not been device-tested on the user's Android phone.
- A compiled APK is not included in this ZIP. The GitHub Actions workflow is the configured route to generate it.
