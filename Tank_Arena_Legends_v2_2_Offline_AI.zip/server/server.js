// Tank Arena: Legends room/matchmaking relay server (v2.1)
// Room relay only: this server does NOT authoritatively simulate or synchronize combat.
const http = require('http');
const { WebSocketServer } = require('ws');
const server = http.createServer((req,res)=>{
  res.writeHead(200,{'content-type':'application/json','cache-control':'no-store'});
  res.end(JSON.stringify({name:'Tank Arena: Legends server',version:'2.1.0',status:'online',rooms:rooms.size}));
});
const wss = new WebSocketServer({server, maxPayload: 8192});
const rooms = new Map();
const clients = new Map();
const RATE_WINDOW_MS = 10000, RATE_MAX = 50;
function send(ws,obj){if(ws.readyState===1)ws.send(JSON.stringify(obj));}
function cleanRoom(code, reason='Room closed.'){
  const r=rooms.get(code); if(!r)return;
  for(const p of r.players){clients.delete(p);send(p,{type:'room-closed',message:reason});}
  rooms.delete(code);
}
function roomCode(){
  const chars='ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; let c;
  do{c=Array.from({length:5},()=>chars[Math.floor(Math.random()*chars.length)]).join('')}while(rooms.has(c));
  return c;
}
function broadcast(r,obj){for(const p of r.players)send(p,obj);}
function roomInfo(code,r){
  return {type:'room',room:code,players:r.players.length,slots:r.players.map(p=>({slot:p.slot,name:p.playerName||'Commander',ready:r.ready.has(p)}))};
}
wss.on('connection',ws=>{
  ws.rate={start:Date.now(),count:0}; ws.slot=-1;
  ws.on('message',raw=>{
    if(Date.now()-ws.rate.start>RATE_WINDOW_MS)ws.rate={start:Date.now(),count:0};
    if(++ws.rate.count>RATE_MAX){send(ws,{type:'error',message:'Too many messages. Slow down.'});ws.close(1008,'Rate limit');return;}
    let m; try{m=JSON.parse(raw.toString())}catch{return}
    if(!m||typeof m.type!=='string')return;
    if(m.type==='create'){
      if(clients.has(ws))return;
      const code=roomCode(),r={players:[ws],ready:new Set(),created:Date.now()};
      ws.slot=0; ws.playerName=String(m.name||'Commander').slice(0,16);
      rooms.set(code,r);clients.set(ws,code);
      send(ws,{type:'waiting',room:code,players:1,slot:0});return;
    }
    if(m.type==='join'){
      if(clients.has(ws)){send(ws,{type:'error',message:'You are already in a room.'});return}
      const code=String(m.room||'').toUpperCase(),r=rooms.get(code);
      if(!r){send(ws,{type:'error',message:'Room not found. Check the code.'});return}
      if(r.players.length>=2){send(ws,{type:'error',message:'Room is full.'});return}
      ws.slot=1; ws.playerName=String(m.name||'Commander').slice(0,16);
      r.players.push(ws);clients.set(ws,code);
      broadcast(r,roomInfo(code,r));
      broadcast(r,{type:'peer-joined',name:ws.playerName,slot:1});return;
    }
    const code=clients.get(ws),r=code&&rooms.get(code); if(!r)return;
    if(m.type==='ready'){
      r.ready.add(ws);broadcast(r,{type:'ready-state',ready:r.ready.size});
      if(r.ready.size===2)broadcast(r,{type:'match-ready',room:code,players:r.players.map(p=>p.playerName||'Commander'),slots:r.players.map(p=>p.slot)});
      return;
    }
    if(m.type==='relay'){
      const payload=m.payload;
      if(!payload||typeof payload!=='object'||Array.isArray(payload))return;
      const encoded=JSON.stringify(payload); if(encoded.length>4096)return;
      // Relay only to the other participant. The client must validate and apply gameplay events.
      for(const peer of r.players)if(peer!==ws)send(peer,{type:'peer-message',from:ws.slot,payload});
    }
  });
  ws.on('close',()=>{
    const code=clients.get(ws);clients.delete(ws);if(!code)return;
    const r=rooms.get(code);if(!r)return;
    r.players=r.players.filter(p=>p!==ws);r.ready.delete(ws);
    if(!r.players.length)rooms.delete(code);
    else broadcast(r,{type:'peer-left',players:r.players.length,slot:ws.slot});
  });
  ws.on('error',()=>{});
});
const port=process.env.PORT||8080;
server.listen(port,()=>console.log(`Tank Arena Legends relay listening on ${port}`));
